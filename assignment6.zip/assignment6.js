function loadGallery() {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onload = function () { 
        loadImages(JSON.parse(xmlhttp.responseText));     
    };
    xmlhttp.open("GET", "images.json", true);
    xmlhttp.send();
}

function loadImages(imgData) {
    for (let i = 0; i < imgData.length; i++) {
        //Slide Div
        var slide = document.createElement("div");
        slide.setAttribute('class', 'slide');
        //Slide number
        var num = document.createElement("div");
        num.setAttribute('class', 'number');
        num.innerHTML = i + 1 + imgData.length;
        //Image
        var img = document.createElement("img");
        img.setAttribute('class', 'imgClass');
        img.src = imgData[i].image_name;        
        //Append to slide container div
        document.getElementById("container").appendChild(slideDiv);
        slide.appendChild(num);
        slide.appendChild(img);        
    }
    showSlides(slideIndex);
    
}

var slideIndex = 1;

function nextSlide(n) {
    showSlides(slideIndex += n);
}

function currentSlide(n) {
    showSlides(slideIndex = n);
}

function showSlides(n) {
    var i;
    var slides = document.getElementsByClassName('slide');
    console.log(slides.length);   
    if (n > slides.length) {
        slideIndex = 1
    }
    if (n < 1) {
        slideIndex = slides.length
    }    
    slides[slideIndex - 1].style.display = "block";    
}

document.addEventListener("DOMContentLoaded", function () {
    loadGallery();
});